#define _GNU_SOURCE
#include <stdio.h>
#include <linux/kernel.h>
#include <sys/syscall.h>
#include <unistd.h>

#define sys_kernel_2d_memcpy 548
void main(){

    double a[5][2] = {{3.54,2.79}, {3.14,6.625}, {1.67,9.1}, {1.23,2.34}, {3.45,4.567}};
    double b[5][2];
    int i = syscall(sys_kernel_2d_memcpy,*a,*b,5,2);
    for(int j=0;j<5;j++){
        for(int k=0;k<2;k++){
            printf("%f ",b[j][k]);
        }
        printf("\n");
    }
}