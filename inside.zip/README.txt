The folder contains:
	
	1) The diff file etween stock kernel and changed kernel
	
	2) A test file written in C to test the newly added system call

	3) A makefile for running the test file


How to run the test file:

	Navigate to the Q2 folder using cd command

	Run "make" command

 
Explanation:
	
	1) First I registered the syscall in the syscall table in arch/x86/entry/syscalls/syscall_64.tbl

	2) Define the system call in kernel/sys.c

	3) The syscall takes two 2D arrays as arguments and copies the contents of one array to another.

	4) Saved the changes in both the files and compile the kernel using make.

	5) Ran the testfile to check if the syscall works

	6) Did all the artix installation steps after compilation.

	7) Successfully rebooted the VM to implement the changes

	8) Create a diff file of the kernel using git diff (add the changed files to git before making the changes) 
   


